<?php
// Intentionally left blank to test that htaccess rewrite rules are working. 
// Accessing this file from http should produce a '403 forbidden' error,
// since all PHP files are blocked under /assets/.
