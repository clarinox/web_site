<?php ?>

<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Clarinox - Embedded Bluetooth and WiFi Solutions</title>

<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="white" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="HandheldFriendly" content="true">
<meta name="MobileOptimized" content="width">
<meta name="theme-color" content="#fff ">
<meta name="description" content="<?php echo $page->meta_description ?>">
<meta name="keywords" content="<?php echo $page->meta_keywords ?>">
<meta name="author" content="">

<script type='application/ld+json'> 
{
  "@context": "http://www.schema.org",
  "@type": "Organization",
  "name": "Clarinox Technologies Pty Ltd",
  "url": "https://www.clarinox.com/",
  "foundingDate" : "2001",
  "founders": [
  {
  "@type": "Person",
  "name": "Trish Messiter"
  },
  {
  "@type": "Person",
  "name": "Gokhan Tanyeri"
  } ],
  "logo": "https://media.licdn.com/dms/image/C4D0BAQEaXgElUPRq0A/company-logo_200_200/0?e=2159024400&v=beta&t=dxRaLY5DzcHjYhCNb3cajFbWazGMWWO_nX4xt61qZZQ",
  "description": "Clarinox Technologies is a wireless embedded systems provider founded in 2001 by Trish Messiter and Gokhan Tanyeri. Clarinox has sales offices worldwide with its main head office located in Cheltenham, Melbourne, Australia.",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "28/296 Bay Rd, Cheltenham",
    "addressLocality": "Melbourne",
    "addressRegion": "Victoria",
    "postalCode": "3192",
    "addressCountry": "Australia"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "(03) 9095 8088"
  }
}
 </script>

<!---- Home Page Slider---->
<link rel="stylesheet" type="text/css" href="<?php echo $config->urls->templates?>css/revolution-slider-options.css" media="screen" />

</head> 
<body>
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/custom.css">
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/custom-responsive.css">
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/font-awesome.css">
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/bootstrap-touch-slider.css">
<link rel="stylesheet" type="text/css" media="all" href="<?php echo $config->urls->templates?>css/stellarnav.css">
<!---- Slick Slider ------->
<link href="<?php echo $config->urls->templates?>slick/slick.css" rel="stylesheet">
<link href="<?php echo $config->urls->templates?>slick/slick-theme.css" rel="stylesheet">
<!---- Google Font ------->
<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">

<?php include('./nav.php'); ?>

<!-- Revolution Slider -->
<div class="fullwidthbanner-container top-shadow">
    <div class="fullwidthbanner">
        <ul><?php
            foreach($page->sliders as $slider) {
                echo "<li data-masterspeed='100' data-slotamount='4' data-transition='fade'>
                <img alt='' src='{$slider->url}'/></li>";
            }
        ?></ul>
    </div>
</div>
<!-- Revolution Slider -->


<div class="container-fluid banner_bottom_color">
<div class="container">
<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 nopadding">
     <p class="quote_txt text-center"><?php echo $page->slogan?></p>
</div> 
</div>
</div>
<div class="clearfix">&nbsp;</div>

<div class="container">
  <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 nopadding">
       <h3 class="page_heading text-center uppercase">PRODUCTS & SOLUTIONS</h3>
  </div> 
  <div class="clearfix">&nbsp;</div>
  <div class="clearfix">&nbsp;</div>
  <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 nopadding">
      <?php foreach($page->featured_products as $product) { ?>
          <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
              <div class="col-xs-12 service_bx">
                <a href="<?php echo $product->url ?>">
                    <div class="icon_sec">
                      <!-- <i class="<?php echo $product->product_icon ?>" style="font-size:42px" aria-hidden="true"></i>-->
                       <img src="<?php echo $product->images->get('product-icon.png')->url?>" class="img-responsive" height="100" width="100"></img>
                    </div>
                </a>
                  <div class="cont_sec">
                      <p class="service_head"><a href="<?php echo $product->url ?>"><?php echo $product->product_name ?></a></p>
                      <p class="service_cont"><?php echo $product->headline ?></p>
                  </div>
              </div>
          </div>
      <?php } ?>
      <div class="clearfix">&nbsp;</div>
      <a href="products" class="service_more">See More..</a>
  </div>
</div>

<div class="clearfix">&nbsp;</div>
<div class="container-fluid clients_sec">
<div class="container">
    <a href="/products/softframe/supported-platforms" >
    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 nopadding">
     <h3 class="page_heading text-center theme_white">Supported Platform</h3>
        <div class="clearfix">&nbsp;</div>
</div> 
    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 nopadding">
    <div class="slider responsive">
        <?php
        foreach($page->platforms as $platform) {
            echo "<div><img src='{$platform->url}' class='clogo'' /></div>";
        } ?>
    </div>
 <div class="clearfix">&nbsp;</div>
    </div>
    </a>
</div>   
</div> 
<div class="clearfix">&nbsp;</div>
<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 nopadding">
     <h3 class="page_heading text-center theme_color uppercase">CASE STUDIES</h3>
</div> 

<div class="clearfix">&nbsp;</div>
<div class="container">

    <div class="col-md-12 col-sm-12 col-xs-12 nopadding">
        <div class="slider single-item">

            <?php
            // substr(strrchr($pages->find("template=video, sort=-created")->first()->link,"/"),1)
            $filter="parent=/resources/case-studies, sort=-custom_published_date, limit=4";
            //echo $filter;
            $cases = $pages->find($filter);
            foreach($cases as $case) {
                //echo "<div><img src='{$platform->url}' class='clogo'' /></div>";
            ?>

            <div>
                <?php if(count($case->images)) {?>
                <div class="col-sm-2 col-md-2 col-xs-12">
                    <img src="<?php echo $case->images->first()->url?>" class="img-responsive" alt="img" height="200" width="200"/>
                </div>
                <div class="clearfix visible-xs">&nbsp;</div>
                <?php } ?>

                <div class="col-sm-10 col-md-10 col-xs-12">
                    
                    <p><?php echo $case->title ?></p>
                    <p><?php echo $case->summary ?></p>
                </div>

            </div>

            <?php } ?>
        </div>


    </div>

      <div class="clearfix">&nbsp;</div>
</div>
<div class="clearfix">&nbsp;</div>

<div class="container-fluid videos_back"> 
<div class="container">
    <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 nopadding">
        <div class="col-md-4  col-sm-4 col-xs-12">
            <div class="col-xs-12 right_line nopadding">
                <div class="line"></div>
            <p class="video_tit">Videos</p>

            <div id="player"></div>
            </div>
            <div class="col-xs-12 right_line nopadding">
                <a href="resources/videos" class="read_morebtt">Read More..</a>
            </div>
        </div>
        <div class="col-md-4 col-sm-4 col-xs-12">
             <div class="col-xs-12 right_line nopadding">
                    <div class="line"></div>
              <p class="video_tit">Newsletter</p>

                 <!--<?php echo substr(strrchr($pages->find("template=video, sort=-created")->first()->link,"/"),1); ?>-->

                <ul class="newsl_hm">

                    <?php
                    $year = (int)date("Y");
                    $parent_str = "/resources/newsletters/" . $year . "/";
                    
                    
                   
                    $newsletters = $pages->find("parent=$parent_str, sort=-custom_published_date, limit=5");
                    
                    if (count($newsletters) == 0){
                        $year = date('Y') - 1; 
                        $newsletters = $pages->find("parent=/resources/newsletters/$year/, sort=-custom_published_date");    
                    }

                    //$newsletters = $pages->find("template=newsletter, sort=-created, limit=5");
                    foreach ($newsletters as $newsletter) {
                    ?>

                    <li><?php echo $newsletter->headline ?></li>

                    <?php } ?>

                </ul>

                <div class="col-xs-12 right_line nopadding">
                <a href="resources/newsletters" class="read_morebtt">Read More...</a>
                 </div>
            </div>
        </div>

         <div class="col-md-4 col-sm-4 col-xs-12">
             <p class="video_tit">Twitter Feeds</p>
              <div class="col-xs-12 nopadding">
                  
                  <?php
                  $options = array(
                      'limit' => 3,
                      'cacheSeconds' => 600, // 10 minutes
                      'showDate' => 'before',
                      'listItemDateClose' => '. </span>',
                      'screenName' => 'clarinox'
                  );
                  $t = $modules->get('MarkupTwitterFeed');
                  echo $t->render($options);
                  ?>

<!--
                  <ul>
  <li> <span class='date'>March 31 12:03 am</span>. How to Retrofit Industry with Wireless IoT Connectivity <a rel='nofollow' href='https://buff.ly/2TZWieC'>buff.ly/2TZWieC</a> https://t.co/RG0anr7RDN</li>
  <li> <span class='date'>March 29 9:13 pm</span>. Don&#039;t have footprint to add wireless into an existing design? Perhaps there is a solution for you&hellip; <a rel='nofollow' href='https://twitter.com/i/web/status/1111571958800494595'>twitter.com/i/web/status/1…</a></li>
  <li> <span class='date'>March 29 12:08 am</span>. Ready to start your short range wireless upgrade? visit Clarinox at #HMI19 co-exhibiting with @R3Coms Hall 9, Stand&hellip; <a rel='nofollow' href='https://twitter.com/i/web/status/1111253612729122817'>twitter.com/i/web/status/1…</a></li>
</ul>
-->
                   <div class="col-xs-12 right_line nopadding">
            </div>
             </div>
        </div>


    </div>    
</div>
</div>

<div  class="container-fluid address_back">
<div class="container">
 <div class="clearfix">&nbsp;</div>
 <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 nopadding">
    <div class="col-md-6 col-sm-6 col-xs-12">
        <?php $image = $page->images->first(); ?>
        <img src="<?php echo $image->url ?>" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></img>
    </div>
     <div class="col-md-6 col-sm-6 col-xs-12 social_right-top col-sm-4 col-xs-12">
         <div class="col-md-8 col-sm-10 col-xs-12 nopadding">
         <div class="col-xs-12 nopadding">
            <p class="address_tit">Clarinox Head Office</p> 
             <p class="address">
            <i class="fa fa-map-marker theme_color" aria-hidden="true"></i> &nbsp;  28/296 Bay Road,<br/>
Cheltenham,VIC 3192<br/>
AUSTRALIA
             </p>
             <p class="phone">
              <i class="fa fa-phone theme_color" aria-hidden="true"></i> &nbsp;  +61 3 9095 8088  
             </p>
            </div>
         <div class="clearfix">&nbsp;</div>
         <div class="col-xs-12 nopadding">
            <p class="address_tit">Global Agents</p> 

             <p class="address">To be in touch with one of our regional offices,
please contact the Head Office and we will be more
than happy to redirect your enquiry to the right person.</p>


         </div>

         </div>
         <!--
          <div class="social_icon">
             <ul class="social-network social-circle">
                    <li><a href="#" class="icoyoutube" title="youtube"><i class="fa fa-youtube-square" aria-hidden="true"></i></a></li>
                    <li><a href="#" class="icotumb" title="tumbler"><i class="fa fa-tumblr" aria-hidden="true"></i></a></li>
                    <li><a href="#" class="iconln" title="linkedin +"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                      <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>

                </ul>     

         </div>-->

         <div class="social_icon">
                <ul class="social-network social-circle">
                    <?php
                        $company = $pages->get("/company");

                    ?>
                    <li><a href='<?php echo $company->link_youtube; ?>' class="icoyoutube" title="youtube">
                        <i class="fa fa-youtube-square" aria-hidden="true"></i></a></li>
                    <li><a href='<?php echo $company->link_twitter; ?>' class="icotwitter" title="twitter">
                        <i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                    <li><a href='<?php echo $company->link_linkedin; ?>' class="iconln" title="linkedin +">
                        <i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                    <li><a href='<?php echo $company->link_facebook; ?>' class="icoFacebook" title="Facebook">
                        <i class="fa fa-facebook"></i></a></li>

                </ul>
            </div>

     </div>
 </div>
 <div class="clearfix">&nbsp;</div>
</div>
</div>


   
<footer>
<div class="container">

    <div class="col-md-12 col-sm-12 col-xs-12 nopadding">
        <p>Copyright © 2019 Clarinox Pty.Ltd., All Rights Reserved.</p>
    </div>
</div>  
</footer>

<div class="totop"><i class="fa fa-angle-up"></i> </div>


<script src="<?php echo $config->urls->templates?>js/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>js/modernizr.min.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>js/totop.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>js/bootstrap-touch-slider.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>slick/slick.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="https://www.youtube.com/player_api"></script>
<script type="text/javascript" src="<?php echo $config->urls->templates?>js/stellarnav.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function($) {
      jQuery('.stellarnav').stellarNav({
        theme: 'dark'
      });
    });
</script>

<script>
  $( '#bootstrap-touch-slider' ).bsTouchSlider();
</script>

<script>
var player;
function onYouTubeIframeAPIReady() {
    player = new YT.Player('player', {
height: '200',
width: '280px',
rel: '0',
videoId: '<?php echo substr(strrchr($pages->find("template=video, sort=-custom_published_date")->first()->link,"/"),1) ?>'
});
}

$(document).on('mouseover', '#player', function() {
    player.playVideo();
});
$(document).on('mouseout', '#player', function() {
    player.pauseVideo();
});
</script>


<script>

$('.single-item').slick();

</script>
<script>
$('.totop').tottTop({
scrollTop: 100
});
</script>
<script type="text/javascript">


    $(function(){
        var header = $('#header');
        $(window).scroll(function(){
            var scroll = $(window).scrollTop();
            if (scroll >= 30){

                $('#header').addClass('pghead');


            } else {


                $('#header').removeClass('pghead');
            }

        });
    });

</script>
<script>

$(function(){
    var header = $('#main-nav');
    $(window).scroll(function(){
        var scroll = $(window).scrollTop();
        if (scroll >= 30){

            $('#main-nav').addClass('mob_fit');


        } else {


            $('#main-nav').removeClass('mob_fit');
        }

    });
});

</script>
<script>
( function() {

    $('#btn-search').on('click', function(e) {

          
          e.preventDefault();
          $('#search').animate({width: 'toggle'}).focus();
          q = document.getElementById('search').value;

          if(q == ''){
            //do nothing
          } else {
            $('#form-search').submit();

          }
  });

} () );


</script>


<script type="text/javascript" src="<?php echo $config->urls->templates?>js/jquery.themepunch.plugins.min.js"></script>
<script type="text/javascript" src="<?php echo $config->urls->templates?>js/jquery.themepunch.revolution.js"></script>
<script type="text/javascript" src="<?php echo $config->urls->templates?>js/revolution-slider-options.js"></script>




<script>
$('.responsive').slick({

infinite: true,
speed: 300,
autoplay: true,
slidesToShow: 6,
slidesToScroll: 6,
responsive: [
{
    breakpoint: 1024,
  settings: {
    autoplay: true,
      arrows: false,
    slidesToShow: 2,
    slidesToScroll: 2,
    infinite: true,
    dots: true
  }
},
{
    breakpoint: 600,
  settings: {
    autoplay: true,
       arrows: false,
    slidesToShow: 2,
        dots:true,
    slidesToScroll: 2
  }
},
{
    breakpoint: 480,
  settings: {
    autoplay: true,
    slidesToShow: 2,
      dots:true,
       arrows: false,
    slidesToScroll: 2
  }
}

]
});


</script>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-819076-1");
pageTracker._trackPageview();
} catch(err) {}</script>

</body>
</html>