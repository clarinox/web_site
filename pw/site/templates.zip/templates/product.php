<?php ?>

<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Clarinox | <?php echo $page->title ?></title>
    
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="white" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="HandheldFriendly" content="true">
    <meta name="MobileOptimized" content="width">
    <meta name="theme-color" content="#fff ">
    <meta name="description" content="<?php echo $page->meta_description ?>">
    <meta name="keywords" content="<?php echo $page->meta_keywords ?>">
    <meta name="author" content="">

    <!----- Nav Bottom line css  --->
    <link rel="stylesheet" href="<?php echo $config->urls->templates?>css/nav_style.css" >

    <link rel="stylesheet" href="<?php echo $config->urls->templates?>css/bootstrap-select.css">
</head>
<body>
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/custom.css">
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/custom-responsive.css">
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/font-awesome.css">
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/bootstrap-touch-slider.css">
<link rel="stylesheet" href="<?php echo $config->urls->templates?>css/modal.css">
<link rel="stylesheet" type="text/css" media="all" href="<?php echo $config->urls->templates?>css/stellarnav.css">
<!---- Slick Slider ------->
<link href="<?php echo $config->urls->templates?>slick/slick.css" rel="stylesheet">
<link href="<?php echo $config->urls->templates?>slick/slick-theme.css" rel="stylesheet">
<!---- Google Font ------->
<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">

<?php include('./nav.php'); ?>

<div id="myModal" class="modal">
  <span class="close_button">&times;</span>
  <img class="modal-content" id="img01">
</div>

<div class="container">
    <div class="col-md-12 col-sm-12 col-xs-12 nopadding">
        <div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
            <center><img src="<?php echo $page->images->first()->url ?>" class="img-responsive" alt="img" /></center>
        </div>
        <div class="col-md-8 col-sm-8 col-lg-8 col-xs-12">
            <div class="col-md-12 col-lg-12 col-sm-12 page_cont col-xs-12 nopadding">
                <h3 class="page_heading theme_color"><?php echo $page->headline ?></h3>
            </div>
            <p><?php echo $page->summary ?></p>

        </div>
    </div>

</div>
<div class="learfix">&nbsp;</div>

<?php echo $page->body ?>

<div class="learfix">&nbsp;</div>
<div class="container">
    <div class="col-md-12 page_cont col-lg-12 col-sm-12 page_cont col-xs-12 nopadding">
        <h3 class="page_heading theme_color    ">
            Video
        </h3>
    </div>
    <div class="col-md-12 page_cont col-lg-12 col-sm-12 page_cont col-xs-12 nopadding">
        <div class="product_det_vid">
            <iframe width="100%" height="300" src="https://www.youtube.com/embed/j0Fb6wR8fVU?showinfo=0" frameborder="0" allowfullscreen></iframe>
        </div>
    </div>
</div>
<div class="learfix">&nbsp;</div>
<div class="container-fluid product_det_gray">
<div class="container">
        <div class="col-md-12 page_cont col-lg-12 col-sm-12 page_cont col-xs-12 nopadding">
            <h3 class="page_heading theme_color   ">
                Supported Platforms
            </h3>
<p>For a full range of supported platforms, please refer to <a href="http://clarinox.com/products/softframe/supported-platforms">Supported Platforms</a>
        </div>
    </div>
    <div class="learfix">&nbsp;</div>
</div>
<div class="learfix">&nbsp;</div>
<div class="container">
    <div class="learfix">&nbsp;</div>
    <div class="col-md-12 col-sm-12 col-xs-12 nopadding product_list">
        <div class="col-md-3 col-sm-4 col-xs-12">
            <div class="product_left company_left">
                <div class="inner_cont">
                <span class="icon_text">
                 Related Videos
                </span>
                </div>
            </div>
        </div>

        <div class="col-md-9 col-sm-8 col-xs-12">

            <?php
            $videos = $pages->find("template=video, sort=-custom_published_date, tags=$page->tags, limit=3");
            foreach ($videos as $video){
            ?>

            <div class=" col-md-4 col-sm-4 col-xs-12 mob_pad_none">
                <div class="product_cont_bx">
                    <iframe width="100%" height="100%" src="<?php echo str_ireplace("/v/","/embed/",
                        $video->link); ?>?showinfo=0" frameborder="0" allowfullscreen></iframe>
                </div>
            </div>

            <?php } ?>

        </div>



    </div>

    <div class="col-md-12 col-sm-12 col-xs-12 nopadding product_list">
        <div class="col-md-3 col-sm-4 col-xs-12">
            <div class="product_left company_left">
                <div class="inner_cont">
                <span class="icon_text">
                 Related News
                </span>
                </div>
            </div>
        </div>
        <div class="col-md-9 col-sm-8 col-xs-12">

            <?php
            $newsletters = $pages->find("template=newsletter, sort=-custom_published_date, tags=$page->tags, limit=3");
            foreach ($newsletters as $newsletter){
                $content = $newsletter->title . ': ' . $newsletter->summary;
                if (strlen($content) > 150)
                    $content = substr ($content, 0, 150) . ' ...';
            ?>


            <div class=" col-md-4 col-sm-4 col-xs-12 mob_pad_none">
                <div class="product_cont_bx">
                    <p class="product_det"><?php echo $content ?></p>
                    <p class="pro_read"><a href="<?php echo $config->urls->root ?>resources/newsletters">Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></p>
                </div>
            </div>

            <?php } ?>
        </div>
    </div>
<!--
    <div class="col-md-12 col-sm-12 col-xs-12 nopadding product_list">
        <div class="col-md-3 col-sm-4 col-xs-12">
            <div class="product_left company_left">
                <div class="inner_cont">
                <span class="icon_text">
                 Related Tweets
                </span>
                </div>
            </div>
        </div>
        <div class="col-md-9 col-sm-8 col-xs-12">
            <div class=" col-md-4 col-sm-4 col-xs-12 ">
                <div class="product_cont_bx">
                    <p class="product_det">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
                    </p>

                    <p class="pro_read"><a href="#">Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></p>
                </div>
            </div>
            <div class=" col-md-4 col-sm-4 col-xs-12 ">
                <div class="product_cont_bx">
                    <p class="product_det">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
                    </p>

                    <p class="pro_read"><a href="#">Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></p>
                </div>
            </div>
            <div class=" col-md-4 col-sm-4 col-xs-12 ">
                <div class="product_cont_bx">
                    <p class="product_det">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
                    </p>

                    <p class="pro_read"><a href="#">Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></p>
                </div>
            </div>

        </div>
    </div>
-->
</div>

<div class="container-fluid product_det_gray">
    <div class="container">
        <div class="col-md-12 page_cont col-lg-12 col-sm-12 page_cont col-xs-12 nopadding">
            <h3 class="page_heading theme_color text-center ">
                Products & Solution
            </h3>
        </div>
    </div>
</div>

<div class="container">
    <div class="clearfix">&nbsp;</div>
    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 nopadding">
        
    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 nopadding">
      <?php $home = $pages->get('/'); ?>
      <?php $products = $pages->get('/products/'); ?>
      <?php foreach($home->featured_products as $product) { ?>
          <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
              <div class="col-xs-12 service_bx">
                  <div class="icon_sec">
                      <!-- <i class="<?php echo $product->product_icon ?>" style="font-size:42px" aria-hidden="true"></i> -->
                     <img src="<?php echo $product->images->get('product-icon.png')->url?>" class="img-responsive" height="100" width="100"></img>
                  </div>
                  <div class="cont_sec">
                      <p class="service_head"><a href="<?php echo $product->url ?>"><?php echo $product->product_name ?></a></p>
                      <p class="service_cont"><?php echo $product->headline ?></p>
                  </div>
              </div>
          </div>
      <?php } ?>
      <div class="clearfix">&nbsp;</div>
      <a href="<?php echo $products->url ?>" class="service_more">See More..</a>
    </div>

    </div>
</div>

<?php include('./footer.php'); ?>

<script src="<?php echo $config->urls->templates?>js/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>js/modernizr.min.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>js/totop.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>js/modal.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>js/bootstrap-touch-slider.js" type="text/javascript"></script>
<script src="<?php echo $config->urls->templates?>slick/slick.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="http://www.youtube.com/player_api"></script>
<script type="text/javascript" src="<?php echo $config->urls->templates?>js/stellarnav.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        jQuery('.stellarnav').stellarNav({
            theme: 'dark'
        });
    });
</script>

<script>
    $( '#bootstrap-touch-slider' ).bsTouchSlider();
</script>




<script>
    var player;
    function onYouTubeIframeAPIReady() {
        player = new YT.Player('player', {
            height: '200',
            width: '280px',
            videoId: 'l6bP2-vpYjc'
        });
    }

    $(document).on('mouseover', '#player', function() {
        player.playVideo();
    });
    $(document).on('mouseout', '#player', function() {
        player.pauseVideo();
    });
</script>
<script>

    $('.single-item').slick();

</script>
<script>
    $('.totop').tottTop({
        scrollTop: 100
    });
</script>
<script type="text/javascript">


    $(function(){
        var header = $('#header');
        $(window).scroll(function(){
            var scroll = $(window).scrollTop();
            if (scroll >= 30){

                $('#header').addClass('pghead');


            } else {


                $('#header').removeClass('pghead');
            }

        });
    });

</script>
<script>

    $(function(){
        var header = $('#main-nav');
        $(window).scroll(function(){
            var scroll = $(window).scrollTop();
            if (scroll >= 30){

                $('#main-nav').addClass('mob_fit');


            } else {


                $('#main-nav').removeClass('mob_fit');
            }

        });
    });

</script>
<script>
( function() {

    $('#btn-search').on('click', function(e) {

          
          e.preventDefault();
          $('#search').animate({width: 'toggle'}).focus();
          q = document.getElementById('search').value;

          if(q == ''){
            //do nothing
          } else {
            $('#form-search').submit();

          }
  });

} () );


</script>


<script>
    $(function() {
        var isXS = false,
            $accordionXSCollapse = $('.accordion-xs-collapse');

        // Window resize event (debounced)
        var timer;
        $(window).resize(function () {
            if (timer) { clearTimeout(timer); }
            timer = setTimeout(function () {
                isXS = Modernizr.mq('only screen and (max-width: 767px)');

                // Add/remove collapse class as needed
                if (isXS) {
                    $accordionXSCollapse.addClass('collapse');
                } else {
                    $accordionXSCollapse.removeClass('collapse');
                }
            }, 100);
        }).trigger('resize'); //trigger window resize on pageload

        // Initialise the Bootstrap Collapse
        $accordionXSCollapse.each(function () {
            $(this).collapse({ toggle: false });
        });

        // Accordion toggle click event (live)
        $(document).on('click', '.accordion-xs-toggle', function (e) {
            e.preventDefault();

            var $thisToggle = $(this),
                $targetRow = $thisToggle.parent('.tr'),
                $targetCollapse = $targetRow.find('.accordion-xs-collapse');

            if (isXS && $targetCollapse.length) {
                var $siblingRow = $targetRow.siblings('.tr'),
                    $siblingToggle = $siblingRow.find('.accordion-xs-toggle'),
                    $siblingCollapse = $siblingRow.find('.accordion-xs-collapse');

                $targetCollapse.collapse('toggle'); //toggle this collapse
                $siblingCollapse.collapse('hide'); //close siblings

                $thisToggle.toggleClass('collapsed'); //class used for icon marker
                $siblingToggle.removeClass('collapsed'); //remove sibling marker class
            }
        });
    });
</script>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-819076-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>
