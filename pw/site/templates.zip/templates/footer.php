<?php ?>

<div class="learfix">&nbsp;</div>
<div class="container-fluid address_back page_foot">
    <div class="container">
        <div class="col-md-3 page_footer col-sm-3 col-xs-12">
            <p class="title">Clarinox Head Office</p>
            <p class="cont">28/296 Bay Road, Cheltenham,VIC 3192 AUSTRALIA</p>
        </div>
        <div class="col-md-4  page_footer col-sm-4 col-xs-12">
            <p class="title">Global Agents</p>
            <p class="cont" >To be in touch with one of our regional offices, please contact the Head Office and we will be
                more than happy to redirect your enquiry to the right person.</p>
        </div>
        <div class="col-md-2 page_footer col-sm-2 col-xs-12 text-center">
            <img class="iso_logo" src="<?php echo $config->urls->templates?>images/9001_small.png" />
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 social_right-top ">
            <div class="social_icon">
                <ul class="social-network social-circle">
                    <?php
                        $company = $pages->get("/company");

                    ?>
                    <li><a href='<?php echo $company->link_youtube; ?>' class="icoyoutube" title="youtube">
                        <i class="fa fa-youtube-square" aria-hidden="true"></i></a></li>
                    <li><a href='<?php echo $company->link_twitter; ?>' class="icotwitter" title="twitter">
                        <i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                    <li><a href='<?php echo $company->link_linkedin; ?>' class="iconln" title="linkedin +">
                        <i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                    <li><a href='<?php echo $company->link_facebook; ?>' class="icoFacebook" title="Facebook">
                        <i class="fa fa-facebook"></i></a></li>

                </ul>
            </div>
        </div>
    </div>
</div>
<footer>
    <div class="container">

        <div class="col-md-12 col-sm-12 col-xs-12 nopadding">
            <p>Copyright © 2019 Clarinox Pty.Ltd., All Rights Reserved.</p>
        </div>
    </div>
</footer>

<div class="totop"><i class="fa fa-angle-up"></i> </div>